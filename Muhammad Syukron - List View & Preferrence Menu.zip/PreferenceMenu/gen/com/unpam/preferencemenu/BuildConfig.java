/** Automatically generated file. DO NOT MODIFY */
package com.unpam.preferencemenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}